CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS businesses (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL,
 phone TEXT, email TEXT, currency TEXT NOT NULL DEFAULT 'KES', timezone TEXT NOT NULL DEFAULT 'Africa/Nairobi',
 plan TEXT NOT NULL DEFAULT 'Free', subscription_status TEXT NOT NULL DEFAULT 'Trial',
 subscription_expires_at TIMESTAMPTZ, mpesa_shortcode TEXT, mpesa_account_reference TEXT,
 settings JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
 name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT, role TEXT NOT NULL DEFAULT 'Owner',
 google_id TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), last_login_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS products (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 name TEXT NOT NULL, sku TEXT, kind TEXT NOT NULL DEFAULT 'product', category TEXT, description TEXT,
 unit_price NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK(unit_price >= 0),
 cost_price NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK(cost_price >= 0),
 stock_qty NUMERIC(14,3) NOT NULL DEFAULT 0, low_stock_threshold NUMERIC(14,3) NOT NULL DEFAULT 5,
 track_stock BOOLEAN NOT NULL DEFAULT true, active BOOLEAN NOT NULL DEFAULT true,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(business_id, sku)
);
CREATE TABLE IF NOT EXISTS customers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 name TEXT NOT NULL, phone TEXT, email TEXT, address TEXT, notes TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS suppliers (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 name TEXT NOT NULL, phone TEXT, email TEXT, address TEXT, notes TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS expenses (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 category TEXT NOT NULL DEFAULT 'General', description TEXT NOT NULL, amount NUMERIC(14,2) NOT NULL CHECK(amount >= 0),
 payment_method TEXT NOT NULL DEFAULT 'Cash', expense_date DATE NOT NULL DEFAULT CURRENT_DATE,
 created_by UUID REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sales (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 receipt_no TEXT NOT NULL, customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
 subtotal NUMERIC(14,2) NOT NULL, discount NUMERIC(14,2) NOT NULL DEFAULT 0, tax NUMERIC(14,2) NOT NULL DEFAULT 0,
 total NUMERIC(14,2) NOT NULL, amount_paid NUMERIC(14,2) NOT NULL DEFAULT 0,
 payment_method TEXT NOT NULL DEFAULT 'Cash', payment_status TEXT NOT NULL DEFAULT 'Pending',
 mpesa_checkout_request_id TEXT, mpesa_merchant_request_id TEXT, mpesa_receipt TEXT,
 created_by UUID REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(business_id, receipt_no)
);
CREATE TABLE IF NOT EXISTS sale_items (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), sale_id UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
 product_id UUID REFERENCES products(id) ON DELETE SET NULL, item_name TEXT NOT NULL,
 quantity NUMERIC(14,3) NOT NULL CHECK(quantity > 0), unit_price NUMERIC(14,2) NOT NULL,
 unit_cost NUMERIC(14,2) NOT NULL DEFAULT 0, line_total NUMERIC(14,2) NOT NULL
);
CREATE TABLE IF NOT EXISTS stock_movements (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE, movement_type TEXT NOT NULL,
 quantity NUMERIC(14,3) NOT NULL, balance_after NUMERIC(14,3) NOT NULL, reference TEXT, notes TEXT,
 created_by UUID REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS invoices (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 invoice_no TEXT NOT NULL, customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
 status TEXT NOT NULL DEFAULT 'Draft', due_date DATE, subtotal NUMERIC(14,2) NOT NULL DEFAULT 0,
 tax NUMERIC(14,2) NOT NULL DEFAULT 0, total NUMERIC(14,2) NOT NULL DEFAULT 0,
 notes TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(business_id, invoice_no)
);
CREATE TABLE IF NOT EXISTS invoice_items (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
 product_id UUID REFERENCES products(id) ON DELETE SET NULL, item_name TEXT NOT NULL,
 quantity NUMERIC(14,3) NOT NULL CHECK(quantity > 0), unit_price NUMERIC(14,2) NOT NULL,
 line_total NUMERIC(14,2) NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
 user_id UUID REFERENCES users(id) ON DELETE SET NULL, action TEXT NOT NULL, entity_type TEXT,
 entity_id TEXT, details JSONB NOT NULL DEFAULT '{}'::jsonb, ip_address TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS mpesa_transactions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
 sale_id UUID REFERENCES sales(id) ON DELETE SET NULL, checkout_request_id TEXT UNIQUE,
 merchant_request_id TEXT, phone TEXT NOT NULL, amount NUMERIC(14,2) NOT NULL, status TEXT NOT NULL DEFAULT 'Initiated',
 result_code TEXT, result_desc TEXT, receipt_number TEXT, raw_callback JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS subscriptions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 plan TEXT NOT NULL, amount NUMERIC(14,2) NOT NULL, status TEXT NOT NULL DEFAULT 'Pending Payment',
 payment_method TEXT NOT NULL DEFAULT 'M-Pesa', mpesa_transaction_id UUID REFERENCES mpesa_transactions(id),
 starts_at TIMESTAMPTZ, expires_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS reminders (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
 title TEXT NOT NULL, description TEXT, due_at TIMESTAMPTZ NOT NULL, status TEXT NOT NULL DEFAULT 'Upcoming',
 google_event_id TEXT, created_by UUID REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS oauth_tokens (
 user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, provider TEXT NOT NULL,
 access_token TEXT, refresh_token TEXT, scope TEXT, expiry_date BIGINT, updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_products_business ON products(business_id);
CREATE INDEX IF NOT EXISTS idx_sales_business_created ON sales(business_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_expenses_business_date ON expenses(business_id, expense_date DESC);
CREATE INDEX IF NOT EXISTS idx_audit_business_created ON audit_logs(business_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mpesa_checkout ON mpesa_transactions(checkout_request_id);
