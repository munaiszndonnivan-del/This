require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const compression = require("compression");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Pool } = require("pg");
const { z } = require("zod");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { google } = require("googleapis");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "false" ? false : (process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false),
  max: 10, idleTimeoutMillis: 30000, connectionTimeoutMillis: 10000
});
app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(",").map(s=>s.trim()) : true }));
app.use(compression());
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false }));
app.use("/api", rateLimit({ windowMs: 15*60*1000, limit: 300, standardHeaders: true, legacyHeaders: false }));
const schemaPath = path.join(__dirname, "schema.sql");
let schemaReady;
async function initDb() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
  const sql = fs.readFileSync(schemaPath, "utf8");
  await pool.query(sql);
}
function dbReady(req,res,next){ Promise.resolve(schemaReady).then(()=>next()).catch(e=>next(e)); }
const query = (sql, params=[]) => pool.query(sql, params);
const money = n => Math.round((Number(n)||0)*100)/100;
const slugify = s => String(s||"business").toLowerCase().trim().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,50) || "business";
const jwtSecret = () => { if(!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) throw new Error("JWT_SECRET must be at least 32 characters"); return process.env.JWT_SECRET; };
function tokenFor(user){ return jwt.sign({sub:user.id,businessId:user.business_id,role:user.role,email:user.email},jwtSecret(),{expiresIn:"7d",issuer:"munaiszn"}); }
function auth(req,res,next){
  try { const h=req.headers.authorization||""; const token=h.startsWith("Bearer ")?h.slice(7):null; if(!token) return res.status(401).json({error:"Sign in required"});
    req.user=jwt.verify(token,jwtSecret(),{issuer:"munaiszn"}); next();
  } catch(e){ return res.status(401).json({error:"Session expired or invalid. Sign in again."}); }
}
const roles = (...allowed) => (req,res,next) => allowed.includes(req.user.role) ? next() : res.status(403).json({error:"Your role does not have permission for this action"});
const audit = async (req,action,entityType=null,entityId=null,details={}) => {
  try { await query("INSERT INTO audit_logs(business_id,user_id,action,entity_type,entity_id,details,ip_address) VALUES($1,$2,$3,$4,$5,$6,$7)",[req.user?.businessId||null,req.user?.sub||null,action,entityType,entityId,JSON.stringify(details),req.ip]); } catch(e){ console.error("audit log failed",e.message); }
};
const getBusiness = async id => (await query("SELECT * FROM businesses WHERE id=$1",[id])).rows[0];
const cleanUser = u => ({id:u.id,name:u.name,email:u.email,role:u.role,business_id:u.business_id});
const asyncRoute = fn => (req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);

app.get("/api/health", (req,res)=>res.json({ok:true,service:"MUNAISZN Business Manager",time:new Date().toISOString()}));
app.get("/api/config", (req,res)=>res.json({appName:"MUNAISZN Business Manager",currency:"KES",timezone:"Africa/Nairobi",googleEnabled:!!(process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET),mpesaEnvironment:process.env.MPESA_ENV||"sandbox",supportEmail:process.env.SUPPORT_EMAIL||""}));

app.post("/api/auth/register", asyncRoute(async(req,res)=>{
  const body=z.object({name:z.string().min(2).max(100),email:z.string().email().max(200),password:z.string().min(10).max(128),businessName:z.string().min(2).max(120),phone:z.string().max(30).optional()}).parse(req.body);
  const email=body.email.toLowerCase();
  if((await query("SELECT id FROM users WHERE email=$1",[email])).rowCount) return res.status(409).json({error:"An account with this email already exists"});
  const base=slugify(body.businessName); let slug=base, i=1;
  while((await query("SELECT id FROM businesses WHERE slug=$1",[slug])).rowCount) slug=`${base}-${i++}`;
  const client=await pool.connect();
  try{
    await client.query("BEGIN");
    const b=(await client.query("INSERT INTO businesses(name,slug,phone,email) VALUES($1,$2,$3,$4) RETURNING *",[body.businessName,slug,body.phone||null,email])).rows[0];
    const hash=await bcrypt.hash(body.password,12);
    const u=(await client.query("INSERT INTO users(business_id,name,email,password_hash,role) VALUES($1,$2,$3,$4,'Owner') RETURNING *",[b.id,body.name,email,hash])).rows[0];
    await client.query("INSERT INTO audit_logs(business_id,user_id,action,entity_type,details) VALUES($1,$2,'account.created','business',$3)",[b.id,u.id,JSON.stringify({businessName:b.name})]);
    await client.query("COMMIT");
    res.status(201).json({token:tokenFor(u),user:cleanUser(u),business:{id:b.id,name:b.name,plan:b.plan,subscription_status:b.subscription_status}});
  }catch(e){await client.query("ROLLBACK");throw e;}finally{client.release();}
}));
app.post("/api/auth/login", asyncRoute(async(req,res)=>{
  const body=z.object({email:z.string().email(),password:z.string().min(1)}).parse(req.body);
  const u=(await query("SELECT * FROM users WHERE email=$1",[body.email.toLowerCase()])).rows[0];
  if(!u || !u.password_hash || !(await bcrypt.compare(body.password,u.password_hash))) return res.status(401).json({error:"Email or password is incorrect"});
  await query("UPDATE users SET last_login_at=now() WHERE id=$1",[u.id]);
  await audit({user:{sub:u.id,businessId:u.business_id},ip:req.ip},"auth.login");
  res.json({token:tokenFor(u),user:cleanUser(u),business:await getBusiness(u.business_id)});
}));
app.get("/api/auth/me",auth,asyncRoute(async(req,res)=>{
 const u=(await query("SELECT id,name,email,role,business_id FROM users WHERE id=$1",[req.user.sub])).rows[0];
 if(!u)return res.status(401).json({error:"Account no longer exists"});
 res.json({user:cleanUser(u),business:await getBusiness(u.business_id)});
}));

app.get("/api/dashboard",auth,asyncRoute(async(req,res)=>{
 const bid=req.user.businessId;
 const [sales,expenses,products,customers,orders,low,monthly,latest]=await Promise.all([
 query("SELECT COALESCE(SUM(total),0) total,COALESCE(SUM(amount_paid),0) paid,COUNT(*) count FROM sales WHERE business_id=$1 AND created_at >= date_trunc('month',now())",[bid]),
 query("SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE business_id=$1 AND expense_date >= date_trunc('month',CURRENT_DATE)",[bid]),
 query("SELECT COUNT(*) count FROM products WHERE business_id=$1 AND active=true",[bid]),
 query("SELECT COUNT(*) count FROM customers WHERE business_id=$1",[bid]),
 query("SELECT COUNT(*) count FROM sales WHERE business_id=$1",[bid]),
 query("SELECT id,name,stock_qty,low_stock_threshold FROM products WHERE business_id=$1 AND active=true AND track_stock=true AND stock_qty<=low_stock_threshold ORDER BY stock_qty ASC LIMIT 10",[bid]),
 query("SELECT to_char(date_trunc('month',created_at),'Mon') month,COALESCE(SUM(total),0) sales FROM sales WHERE business_id=$1 AND created_at>=now()-interval '6 months' GROUP BY 1,date_trunc('month',created_at) ORDER BY date_trunc('month',created_at)",[bid]),
 query("SELECT id,receipt_no,total,payment_status,created_at FROM sales WHERE business_id=$1 ORDER BY created_at DESC LIMIT 8",[bid])
 ]);
 res.json({sales:{...sales.rows[0],total:money(sales.rows[0].total),paid:money(sales.rows[0].paid)},expenses:money(expenses.rows[0].total),products:Number(products.rows[0].count),customers:Number(customers.rows[0].count),orders:Number(orders.rows[0].count),lowStock:low.rows,monthly:monthly.rows,latest:latest.rows});
}));

const entityConfigs={
 products:{table:"products",fields:["name","sku","kind","category","description","unit_price","cost_price","stock_qty","low_stock_threshold","track_stock","active"],required:["name"],search:["name","sku","category"],order:"created_at DESC"},
 customers:{table:"customers",fields:["name","phone","email","address","notes"],required:["name"],search:["name","phone","email"],order:"created_at DESC"},
 suppliers:{table:"suppliers",fields:["name","phone","email","address","notes"],required:["name"],search:["name","phone","email"],order:"created_at DESC"},
 expenses:{table:"expenses",fields:["category","description","amount","payment_method","expense_date"],required:["description","amount"],search:["category","description","payment_method"],order:"expense_date DESC,created_at DESC"},
 invoices:{table:"invoices",fields:["invoice_no","customer_id","status","due_date","subtotal","tax","total","notes"],required:["invoice_no"],search:["invoice_no","status","notes"],order:"created_at DESC"},
 reminders:{table:"reminders",fields:["title","description","due_at","status"],required:["title","due_at"],search:["title","description","status"],order:"due_at ASC"}
};
app.get("/api/:entity",auth,asyncRoute(async(req,res)=>{
 const cfg=entityConfigs[req.params.entity]; if(!cfg)return res.status(404).json({error:"Unknown resource"});
 const search=String(req.query.search||"").slice(0,100);
 const params=[req.user.businessId]; let where="business_id=$1";
 if(search){const clauses=cfg.search.map(c=>{params.push(`%${search}%`);return `${c} ILIKE $${params.length}`});where+=" AND ("+clauses.join(" OR ")+")";}
 const limit=Math.min(Math.max(Number(req.query.limit)||100,1),250);
 const result=await query(`SELECT * FROM ${cfg.table} WHERE ${where} ORDER BY ${cfg.order} LIMIT ${limit}`,params);
 res.json(result.rows);
}));
app.post("/api/:entity",auth,asyncRoute(async(req,res)=>{
 const cfg=entityConfigs[req.params.entity]; if(!cfg)return res.status(404).json({error:"Unknown resource"});
 if(req.params.entity==="expenses" && !["Owner","Manager","Accountant"].includes(req.user.role))return res.status(403).json({error:"Only Owner, Manager or Accountant can record expenses"});
 const body={}; for(const f of cfg.fields) if(req.body[f]!==undefined)body[f]=req.body[f];
 for(const f of cfg.required) if(body[f]===undefined||body[f]===null||body[f]==="")return res.status(400).json({error:`${f} is required`});
 if(req.params.entity==="products"){
  body.unit_price=money(body.unit_price);body.cost_price=money(body.cost_price);
  body.stock_qty=Number(body.stock_qty||0);body.low_stock_threshold=Number(body.low_stock_threshold??5);
  body.track_stock=body.track_stock!==false;body.active=body.active!==false;
 }
 if(req.params.entity==="expenses" && (!Number.isFinite(Number(body.amount))||Number(body.amount)<0))return res.status(400).json({error:"Expense amount must be zero or greater"});
 const cols=["business_id",...Object.keys(body)], vals=[req.user.businessId,...Object.values(body)];
 const sql=`INSERT INTO ${cfg.table} (${cols.join(",")}) VALUES (${vals.map((_,i)=>`$${i+1}`).join(",")}) RETURNING *`;
 const result=await query(sql,vals); await audit(req,`${req.params.entity}.created`,req.params.entity,result.rows[0].id,body);
 res.status(201).json(result.rows[0]);
}));
app.patch("/api/:entity/:id",auth,asyncRoute(async(req,res)=>{
 const cfg=entityConfigs[req.params.entity]; if(!cfg)return res.status(404).json({error:"Unknown resource"});
 const body={};for(const f of cfg.fields)if(req.body[f]!==undefined)body[f]=req.body[f];
 if(!Object.keys(body).length)return res.status(400).json({error:"No editable fields supplied"});
 const vals=Object.values(body);const sets=Object.keys(body).map((f,i)=>`${f}=$${i+1}`);
 vals.push(req.params.id,req.user.businessId);
 const result=await query(`UPDATE ${cfg.table} SET ${sets.join(",")} WHERE id=$${vals.length-1} AND business_id=$${vals.length} RETURNING *`,vals);
 if(!result.rowCount)return res.status(404).json({error:"Record not found"});
 await audit(req,`${req.params.entity}.updated`,req.params.entity,req.params.id,body);res.json(result.rows[0]);
}));
app.delete("/api/:entity/:id",auth,roles("Owner","Manager"),asyncRoute(async(req,res)=>{
 const cfg=entityConfigs[req.params.entity];if(!cfg)return res.status(404).json({error:"Unknown resource"});
 const result=await query(`DELETE FROM ${cfg.table} WHERE id=$1 AND business_id=$2 RETURNING id`,[req.params.id,req.user.businessId]);
 if(!result.rowCount)return res.status(404).json({error:"Record not found"});
 await audit(req,`${req.params.entity}.deleted`,req.params.entity,req.params.id);res.json({ok:true});
}));

app.post("/api/stock/adjust",auth,roles("Owner","Manager"),asyncRoute(async(req,res)=>{
 const body=z.object({productId:z.string().uuid(),quantity:z.number().finite().refine(n=>n!==0),reason:z.string().min(2).max(250)}).parse(req.body);
 const c=await pool.connect();try{
 await c.query("BEGIN");
 const p=(await c.query("SELECT * FROM products WHERE id=$1 AND business_id=$2 FOR UPDATE",[body.productId,req.user.businessId])).rows[0];
 if(!p)throw Object.assign(new Error("Product not found"),{status:404});
 const next=Number(p.stock_qty)+body.quantity;if(next<0)throw Object.assign(new Error("Stock cannot go below zero"),{status:409});
 await c.query("UPDATE products SET stock_qty=$1 WHERE id=$2",[next,p.id]);
 await c.query("INSERT INTO stock_movements(business_id,product_id,movement_type,quantity,balance_after,notes,created_by) VALUES($1,$2,$3,$4,$5,$6,$7)",[req.user.businessId,p.id,body.quantity>0?"Adjustment In":"Adjustment Out",body.quantity,next,body.reason,req.user.sub]);
 await c.query("COMMIT");await audit(req,"stock.adjusted","product",p.id,{quantity:body.quantity,reason:body.reason,balance:next});res.json({ok:true,stock_qty:next});
 }catch(e){await c.query("ROLLBACK");throw e}finally{c.release()}
}));
app.get("/api/stock/ledger",auth,asyncRoute(async(req,res)=>{
 const r=await query("SELECT sm.*,p.name product_name FROM stock_movements sm JOIN products p ON p.id=sm.product_id WHERE sm.business_id=$1 ORDER BY sm.created_at DESC LIMIT 250",[req.user.businessId]);res.json(r.rows);
}));

app.post("/api/sales",auth,asyncRoute(async(req,res)=>{
 const body=z.object({customerId:z.string().uuid().nullable().optional(),items:z.array(z.object({productId:z.string().uuid().nullable().optional(),name:z.string().min(1).max(200).optional(),quantity:z.number().positive().max(100000),unitPrice:z.number().nonnegative().max(100000000)})).min(1),discount:z.number().nonnegative().default(0),tax:z.number().nonnegative().default(0),paymentMethod:z.enum(["Cash","M-Pesa","Card","Bank Transfer","Credit"]).default("Cash"),amountPaid:z.number().nonnegative().optional()}).parse(req.body);
 const c=await pool.connect();try{
 await c.query("BEGIN");let subtotal=0;const lines=[];
 for(const item of body.items){
  let product=null;
  if(item.productId){product=(await c.query("SELECT * FROM products WHERE id=$1 AND business_id=$2 FOR UPDATE",[item.productId,req.user.businessId])).rows[0];if(!product)throw Object.assign(new Error("Product not found in this business"),{status:404});if(product.track_stock&&Number(product.stock_qty)<item.quantity)throw Object.assign(new Error(`Insufficient stock for ${product.name}`),{status:409});}
  const name=product?.name||item.name;if(!name)throw Object.assign(new Error("Each sale item needs a product or name"),{status:400});
  const price=money(product?product.unit_price:item.unitPrice);const lineTotal=money(price*item.quantity);subtotal+=lineTotal;
  lines.push({product,name,quantity:item.quantity,price,cost:money(product?.cost_price||0),lineTotal});
 }
 subtotal=money(subtotal);const discount=money(body.discount);const tax=money(body.tax);const total=money(Math.max(0,subtotal-discount+tax));
 if(discount>subtotal)throw Object.assign(new Error("Discount cannot exceed subtotal"),{status:400});
 const receiptNo=`RCP-${new Date().toISOString().slice(2,10).replace(/-/g,"")}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
 const paid=money(Math.min(body.amountPaid===undefined?(body.paymentMethod==="Credit"?0:total):body.amountPaid,total));
 const status=paid>=total?"Paid":paid>0?"Partially Paid":"Pending";
 const sale=(await c.query("INSERT INTO sales(business_id,receipt_no,customer_id,subtotal,discount,tax,total,amount_paid,payment_method,payment_status,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *",[req.user.businessId,receiptNo,body.customerId||null,subtotal,discount,tax,total,paid,body.paymentMethod,status,req.user.sub])).rows[0];
 for(const l of lines){
  await c.query("INSERT INTO sale_items(sale_id,product_id,item_name,quantity,unit_price,unit_cost,line_total) VALUES($1,$2,$3,$4,$5,$6,$7)",[sale.id,l.product?.id||null,l.name,l.quantity,l.price,l.cost,l.lineTotal]);
  if(l.product?.track_stock){const balance=Number(l.product.stock_qty)-l.quantity;await c.query("UPDATE products SET stock_qty=$1 WHERE id=$2",[balance,l.product.id]);await c.query("INSERT INTO stock_movements(business_id,product_id,movement_type,quantity,balance_after,reference,created_by) VALUES($1,$2,'Sale',$3,$4,$5,$6)",[req.user.businessId,l.product.id,-l.quantity,balance,receiptNo,req.user.sub]);}
 }
 await c.query("COMMIT");await audit(req,"sale.created","sale",sale.id,{receiptNo,total,paymentMethod:body.paymentMethod});
 const items=(await query("SELECT * FROM sale_items WHERE sale_id=$1",[sale.id])).rows;
 res.status(201).json({...sale,items});
 }catch(e){await c.query("ROLLBACK");throw e}finally{c.release()}
}));
app.get("/api/sales",auth,asyncRoute(async(req,res)=>{
 const r=await query("SELECT s.*,c.name customer_name FROM sales s LEFT JOIN customers c ON c.id=s.customer_id WHERE s.business_id=$1 ORDER BY s.created_at DESC LIMIT 250",[req.user.businessId]);res.json(r.rows);
}));
app.get("/api/sales/:id",auth,asyncRoute(async(req,res)=>{
 const s=(await query("SELECT s.*,c.name customer_name,c.phone customer_phone FROM sales s LEFT JOIN customers c ON c.id=s.customer_id WHERE s.id=$1 AND s.business_id=$2",[req.params.id,req.user.businessId])).rows[0];
 if(!s)return res.status(404).json({error:"Receipt not found"});
 s.items=(await query("SELECT * FROM sale_items WHERE sale_id=$1",[s.id])).rows;res.json(s);
}));

function darajaBase(){return (process.env.MPESA_ENV||"sandbox").toLowerCase()==="live"?"https://api.safaricom.co.ke":"https://sandbox.safaricom.co.ke";}
async function darajaToken(){
 const key=process.env.MPESA_CONSUMER_KEY,secret=process.env.MPESA_CONSUMER_SECRET;
 if(!key||!secret)throw Object.assign(new Error("M-Pesa Daraja credentials are not configured"),{status:503});
 const basic=Buffer.from(`${key}:${secret}`).toString("base64");
 const r=await fetch(`${darajaBase()}/oauth/v1/generate?grant_type=client_credentials`,{headers:{Authorization:`Basic ${basic}`}});
 const data=await r.json();if(!r.ok||!data.access_token)throw Object.assign(new Error(data.errorMessage||"Daraja authentication failed"),{status:502});
 return data.access_token;
}
const mpesaPhone = value => {let n=String(value||"").replace(/[^\d+]/g,"").replace(/^\+/,"");if(n.startsWith("0"))n="254"+n.slice(1);if(n.startsWith("7")||n.startsWith("1"))n="254"+n;return /^254[17]\d{8}$/.test(n)?n:null;};
function mpesaPassword(shortcode,passkey,timestamp){return Buffer.from(`${shortcode}${passkey}${timestamp}`).toString("base64");}
function mpesaTimestamp(){const d=new Date();return d.getFullYear()+String(d.getMonth()+1).padStart(2,"0")+String(d.getDate()).padStart(2,"0")+String(d.getHours()).padStart(2,"0")+String(d.getMinutes()).padStart(2,"0")+String(d.getSeconds()).padStart(2,"0");}
app.post("/api/mpesa/stkpush",auth,asyncRoute(async(req,res)=>{
 const body=z.object({phone:z.string().min(9),amount:z.number().int().positive().max(150000),saleId:z.string().uuid().optional(),purpose:z.enum(["sale","subscription"]).default("sale")}).parse(req.body);
 const phone=mpesaPhone(body.phone);if(!phone)return res.status(400).json({error:"Enter a valid Kenyan M-Pesa number, e.g. 0712345678"});
 if(!process.env.MPESA_SHORTCODE||!process.env.MPESA_PASSKEY||!process.env.MPESA_CALLBACK_URL)return res.status(503).json({error:"Configure MPESA_SHORTCODE, MPESA_PASSKEY and a public HTTPS MPESA_CALLBACK_URL first"});
 if(body.purpose==="sale"&&body.saleId){
  const sale=(await query("SELECT * FROM sales WHERE id=$1 AND business_id=$2",[body.saleId,req.user.businessId])).rows[0];
  if(!sale)return res.status(404).json({error:"Sale not found"});
  if(Number(sale.total)-Number(sale.amount_paid)<body.amount)return res.status(400).json({error:"Payment amount exceeds the outstanding balance"});
 }
 const token=await darajaToken(),shortcode=process.env.MPESA_SHORTCODE,timestamp=mpesaTimestamp(),passkey=process.env.MPESA_PASSKEY;
 const payload={BusinessShortCode:shortcode,Password:mpesaPassword(shortcode,passkey,timestamp),Timestamp:timestamp,TransactionType:process.env.MPESA_TRANSACTION_TYPE||"CustomerPayBillOnline",Amount:body.amount,PartyA:phone,PartyB:shortcode,PhoneNumber:phone,CallBackURL:process.env.MPESA_CALLBACK_URL,AccountReference:(process.env.MPESA_ACCOUNT_REFERENCE||"MUNAISZN").slice(0,12),TransactionDesc:(process.env.MPESA_TRANSACTION_DESC||"Business payment").slice(0,13)};
 const response=await fetch(`${darajaBase()}/mpesa/stkpush/v1/processrequest`,{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify(payload)});
 const data=await response.json();
 if(!response.ok||data.ResponseCode!=="0")return res.status(502).json({error:data.errorMessage||data.ResponseDescription||"Safaricom did not accept the STK Push request",darajaCode:data.errorCode||data.ResponseCode||null});
 const tx=(await query("INSERT INTO mpesa_transactions(business_id,sale_id,checkout_request_id,merchant_request_id,phone,amount,status) VALUES($1,$2,$3,$4,$5,$6,'Prompt Sent') RETURNING id,checkout_request_id,status",[req.user.businessId,body.saleId||null,data.CheckoutRequestID,data.MerchantRequestID,phone,body.amount])).rows[0];
 if(body.saleId)await query("UPDATE sales SET payment_method='M-Pesa',payment_status='Awaiting M-Pesa',mpesa_checkout_request_id=$1,mpesa_merchant_request_id=$2 WHERE id=$3 AND business_id=$4",[data.CheckoutRequestID,data.MerchantRequestID,body.saleId,req.user.businessId]);
 await audit(req,"mpesa.stkpush.requested","mpesa_transaction",tx.id,{amount:body.amount,phone:phone.slice(0,5)+"*****"});
 res.status(202).json({ok:true,message:"STK Push request accepted by Daraja. This is not proof of payment; wait for the callback.",transaction:tx,customerMessage:data.CustomerMessage||"Check the phone and enter your M-Pesa PIN."});
}));
app.post("/api/mpesa/callback",asyncRoute(async(req,res)=>{
 // Safaricom callback is public; only mark a transaction paid from a matching checkout ID and successful ResultCode.
 const cb=req.body?.Body?.stkCallback;
 res.status(200).json({ResultCode:0,ResultDesc:"Accepted"});
 if(!cb?.CheckoutRequestID)return;
 try{
  const tx=(await query("SELECT * FROM mpesa_transactions WHERE checkout_request_id=$1",[cb.CheckoutRequestID])).rows[0];
  if(!tx)return;
  const items=cb.CallbackMetadata?.Item||[];const meta={};for(const i of items)if(i.Name)meta[i.Name]=i.Value;
  const success=Number(cb.ResultCode)===0;const receipt=meta.MpesaReceiptNumber||null;
  const client=await pool.connect();try{
   await client.query("BEGIN");
   const current=(await client.query("SELECT * FROM mpesa_transactions WHERE id=$1 FOR UPDATE",[tx.id])).rows[0];
   if(current.status!=="Paid"){
    await client.query("UPDATE mpesa_transactions SET status=$1,result_code=$2,result_desc=$3,receipt_number=$4,raw_callback=$5,updated_at=now() WHERE id=$6",[success?"Paid":"Failed",String(cb.ResultCode),String(cb.ResultDesc||""),receipt,JSON.stringify(req.body),tx.id]);
    if(success&&tx.sale_id){
      const sale=(await client.query("SELECT * FROM sales WHERE id=$1 FOR UPDATE",[tx.sale_id])).rows[0];
      if(sale){const paid=Math.min(Number(sale.total),Number(sale.amount_paid)+Number(tx.amount));await client.query("UPDATE sales SET amount_paid=$1,payment_status=$2,mpesa_receipt=$3 WHERE id=$4",[paid,paid>=Number(sale.total)?"Paid":"Partially Paid",receipt,sale.id]);}
    }
    if(success&&!tx.sale_id){
      const sub=(await client.query("SELECT * FROM subscriptions WHERE mpesa_transaction_id=$1 ORDER BY created_at DESC LIMIT 1 FOR UPDATE",[tx.id])).rows[0];
      if(sub){const expires=new Date(Date.now()+30*24*60*60*1000);await client.query("UPDATE subscriptions SET status='Active',starts_at=now(),expires_at=$1 WHERE id=$2",[expires,sub.id]);await client.query("UPDATE businesses SET plan=$1,subscription_status='Active',subscription_expires_at=$2 WHERE id=$3",[sub.plan,expires,tx.business_id]);}
    }
   }
   await client.query("COMMIT");
  }catch(e){await client.query("ROLLBACK");throw e}finally{client.release()}
 }catch(e){console.error("M-Pesa callback processing error:",e.message)}
}));
app.get("/api/mpesa/transactions",auth,asyncRoute(async(req,res)=>{
 const r=await query("SELECT id,sale_id,phone,amount,status,result_code,result_desc,receipt_number,created_at,updated_at FROM mpesa_transactions WHERE business_id=$1 ORDER BY created_at DESC LIMIT 100",[req.user.businessId]);res.json(r.rows);
}));

app.get("/api/reports/summary",auth,asyncRoute(async(req,res)=>{
 const bid=req.user.businessId;
 const [sales,expenses,profit,methods,top]=await Promise.all([
 query("SELECT COALESCE(SUM(total),0) revenue,COALESCE(SUM(amount_paid),0) collected,COUNT(*) orders FROM sales WHERE business_id=$1 AND created_at>=date_trunc('month',now())",[bid]),
 query("SELECT COALESCE(SUM(amount),0) expenses FROM expenses WHERE business_id=$1 AND expense_date>=date_trunc('month',CURRENT_DATE)",[bid]),
 query("SELECT COALESCE(SUM(si.line_total-si.quantity*si.unit_cost),0) gross_profit FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.business_id=$1 AND s.created_at>=date_trunc('month',now())",[bid]),
 query("SELECT payment_method,COUNT(*) count,COALESCE(SUM(total),0) total FROM sales WHERE business_id=$1 GROUP BY payment_method ORDER BY total DESC",[bid]),
 query("SELECT si.item_name,SUM(si.quantity) quantity,SUM(si.line_total) revenue FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.business_id=$1 GROUP BY si.item_name ORDER BY revenue DESC LIMIT 10",[bid])
 ]);
 res.json({sales:sales.rows[0],expenses:expenses.rows[0],grossProfit:profit.rows[0].gross_profit,netBeforeOtherCosts:money(Number(profit.rows[0].gross_profit)-Number(expenses.rows[0].expenses)),paymentMethods:methods.rows,topProducts:top.rows});
}));
app.get("/api/audit",auth,roles("Owner","Manager","Accountant"),asyncRoute(async(req,res)=>{
 const r=await query("SELECT a.*,u.name user_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id WHERE a.business_id=$1 ORDER BY a.created_at DESC LIMIT 250",[req.user.businessId]);res.json(r.rows);
}));

app.patch("/api/settings/business",auth,roles("Owner","Manager"),asyncRoute(async(req,res)=>{
 const body=z.object({name:z.string().min(2).max(120).optional(),phone:z.string().max(30).optional(),email:z.string().email().optional(),currency:z.string().length(3).optional(),timezone:z.string().max(100).optional(),settings:z.record(z.any()).optional(),mpesa_shortcode:z.string().max(20).optional(),mpesa_account_reference:z.string().max(50).optional()}).parse(req.body);
 const keys=Object.keys(body);if(!keys.length)return res.status(400).json({error:"No settings supplied"});
 const values=keys.map(k=>body[k]);const sets=keys.map((k,i)=>`${k}=$${i+1}`);values.push(req.user.businessId);
 const r=await query(`UPDATE businesses SET ${sets.join(",")} WHERE id=$${values.length} RETURNING *`,values);await audit(req,"business.settings.updated","business",req.user.businessId,body);res.json(r.rows[0]);
}));
app.get("/api/team",auth,roles("Owner","Manager"),asyncRoute(async(req,res)=>{
 const r=await query("SELECT id,name,email,role,created_at,last_login_at FROM users WHERE business_id=$1 ORDER BY created_at",[req.user.businessId]);res.json(r.rows);
}));
app.post("/api/team",auth,roles("Owner"),asyncRoute(async(req,res)=>{
 const body=z.object({name:z.string().min(2),email:z.string().email(),password:z.string().min(10),role:z.enum(["Manager","Cashier","Accountant"])}).parse(req.body);
 const hash=await bcrypt.hash(body.password,12);
 try{const r=await query("INSERT INTO users(business_id,name,email,password_hash,role) VALUES($1,$2,$3,$4,$5) RETURNING id,name,email,role,created_at",[req.user.businessId,body.name,body.email.toLowerCase(),hash,body.role]);await audit(req,"team.member.created","user",r.rows[0].id,{role:body.role});res.status(201).json(r.rows[0]);}catch(e){if(e.code==="23505")return res.status(409).json({error:"That email already has an account"});throw e}
}));
app.patch("/api/team/:id",auth,roles("Owner"),asyncRoute(async(req,res)=>{
 const role=z.enum(["Owner","Manager","Cashier","Accountant"]).parse(req.body.role);
 if(req.params.id===req.user.sub&&role!=="Owner")return res.status(400).json({error:"You cannot remove your own Owner role"});
 const r=await query("UPDATE users SET role=$1 WHERE id=$2 AND business_id=$3 AND id<>$4 RETURNING id,name,email,role",[role,req.params.id,req.user.businessId,req.user.sub]);if(!r.rowCount)return res.status(404).json({error:"Team member not found"});await audit(req,"team.role.updated","user",req.params.id,{role});res.json(r.rows[0]);
}));

app.get("/api/subscriptions/plans",(req,res)=>res.json([{name:"Free",price:0,features:["Basic dashboard","Products and customers","Manual sales"],limits:{users:1,products:50}},{name:"Pro",price:499,features:["Full POS and inventory","Reports and invoices","M-Pesa payment tracking","Up to 5 team members"],limits:{users:5,products:1000}},{name:"Business",price:999,features:["All Pro features","Advanced team permissions","Audit history","Priority support"],limits:{users:20,products:10000}}]));
app.post("/api/subscriptions/checkout",auth,asyncRoute(async(req,res)=>{
 const body=z.object({plan:z.enum(["Pro","Business"])}).parse(req.body);const amount=body.plan==="Pro"?499:999;
 const s=(await query("INSERT INTO subscriptions(business_id,plan,amount,status) VALUES($1,$2,$3,'Pending Payment') RETURNING *",[req.user.businessId,body.plan,amount])).rows[0];
 res.status(201).json({subscription:s,instructions:"Pay the configured MUNAISZN platform subscription Paybill, then submit the transaction reference to support/admin for verification if automatic platform verification is not configured. Do not confuse the platform subscription Paybill with your own business's customer Paybill."});
}));
app.get("/api/subscriptions",auth,asyncRoute(async(req,res)=>{const r=await query("SELECT * FROM subscriptions WHERE business_id=$1 ORDER BY created_at DESC LIMIT 50",[req.user.businessId]);res.json(r.rows)}));
app.post("/api/subscriptions/reference",auth,asyncRoute(async(req,res)=>{
 const body=z.object({subscriptionId:z.string().uuid(),transactionReference:z.string().min(6).max(40)}).parse(req.body);
 const s=(await query("SELECT * FROM subscriptions WHERE id=$1 AND business_id=$2",[body.subscriptionId,req.user.businessId])).rows[0];if(!s)return res.status(404).json({error:"Subscription not found"});
 await audit(req,"subscription.reference.submitted","subscription",s.id,{transactionReference:body.transactionReference});
 res.json({ok:true,message:"Reference recorded in audit log for admin verification. Plan activation remains pending until verified."});
}));

app.get("/api/admin/overview",auth,asyncRoute(async(req,res)=>{
 if(!process.env.PLATFORM_ADMIN_EMAIL||req.user.email.toLowerCase()!==process.env.PLATFORM_ADMIN_EMAIL.toLowerCase())return res.status(403).json({error:"Platform admin access only"});
 const [b,u,s,m]=await Promise.all([query("SELECT COUNT(*) count FROM businesses"),query("SELECT COUNT(*) count FROM users"),query("SELECT COUNT(*) count FROM sales"),query("SELECT status,COUNT(*) count FROM mpesa_transactions GROUP BY status")]);
 res.json({businesses:b.rows[0].count,users:u.rows[0].count,sales:s.rows[0].count,mpesa:m.rows});
}));
app.get("/api/admin/businesses",auth,asyncRoute(async(req,res)=>{
 if(!process.env.PLATFORM_ADMIN_EMAIL||req.user.email.toLowerCase()!==process.env.PLATFORM_ADMIN_EMAIL.toLowerCase())return res.status(403).json({error:"Platform admin access only"});
 const r=await query("SELECT b.*,COUNT(u.id)::int users FROM businesses b LEFT JOIN users u ON u.business_id=b.id GROUP BY b.id ORDER BY b.created_at DESC LIMIT 500");res.json(r.rows);
}));
app.patch("/api/admin/businesses/:id",auth,asyncRoute(async(req,res)=>{
 if(!process.env.PLATFORM_ADMIN_EMAIL||req.user.email.toLowerCase()!==process.env.PLATFORM_ADMIN_EMAIL.toLowerCase())return res.status(403).json({error:"Platform admin access only"});
 const body=z.object({plan:z.enum(["Free","Pro","Business"]).optional(),subscription_status:z.enum(["Trial","Pending Payment","Active","Past Due","Cancelled","Expired"]).optional(),subscription_expires_at:z.string().datetime().nullable().optional()}).parse(req.body);
 const keys=Object.keys(body);if(!keys.length)return res.status(400).json({error:"No changes"});
 const vals=keys.map(k=>body[k]);const sets=keys.map((k,i)=>`${k}=$${i+1}`);vals.push(req.params.id);
 const r=await query(`UPDATE businesses SET ${sets.join(",")} WHERE id=$${vals.length} RETURNING *`,vals);if(!r.rowCount)return res.status(404).json({error:"Business not found"});res.json(r.rows[0]);
}));

function googleClient(){
 if(!process.env.GOOGLE_CLIENT_ID||!process.env.GOOGLE_CLIENT_SECRET||!process.env.GOOGLE_REDIRECT_URI)throw Object.assign(new Error("Google OAuth credentials are not configured"),{status:503});
 return new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID,process.env.GOOGLE_CLIENT_SECRET,process.env.GOOGLE_REDIRECT_URI);
}
app.get("/api/google/auth",auth,asyncRoute(async(req,res)=>{
 const client=googleClient();const state=jwt.sign({userId:req.user.sub,businessId:req.user.businessId},jwtSecret(),{expiresIn:"10m"});
 res.json({url:client.generateAuthUrl({access_type:"offline",prompt:"consent",state,scope:["openid","email","profile","https://www.googleapis.com/auth/calendar.events"]})});
}));
app.get("/api/google/callback",asyncRoute(async(req,res)=>{
 try{
  const state=jwt.verify(String(req.query.state||""),jwtSecret());const client=googleClient();const {tokens}=await client.getToken(String(req.query.code||""));
  await query("INSERT INTO oauth_tokens(user_id,provider,access_token,refresh_token,scope,expiry_date) VALUES($1,'google',$2,$3,$4,$5) ON CONFLICT(user_id) DO UPDATE SET provider='google',access_token=EXCLUDED.access_token,refresh_token=COALESCE(EXCLUDED.refresh_token,oauth_tokens.refresh_token),scope=EXCLUDED.scope,expiry_date=EXCLUDED.expiry_date,updated_at=now()",[state.userId,tokens.access_token,tokens.refresh_token||null,tokens.scope||null,tokens.expiry_date||null]);
  res.redirect("/?google=connected");
 }catch(e){res.redirect("/?google=failed");}
}));
app.post("/api/reminders/:id/calendar",auth,asyncRoute(async(req,res)=>{
 const rem=(await query("SELECT * FROM reminders WHERE id=$1 AND business_id=$2",[req.params.id,req.user.businessId])).rows[0];if(!rem)return res.status(404).json({error:"Reminder not found"});
 const row=(await query("SELECT * FROM oauth_tokens WHERE user_id=$1 AND provider='google'",[req.user.sub])).rows[0];if(!row)return res.status(409).json({error:"Connect Google Calendar first"});
 const client=googleClient();client.setCredentials({access_token:row.access_token,refresh_token:row.refresh_token,expiry_date:Number(row.expiry_date)||undefined});
 const calendar=google.calendar({version:"v3",auth:client});
 const event=await calendar.events.insert({calendarId:"primary",requestBody:{summary:rem.title,description:rem.description||"",start:{dateTime:new Date(rem.due_at).toISOString()},end:{dateTime:new Date(new Date(rem.due_at).getTime()+30*60000).toISOString()}}});
 await query("UPDATE reminders SET google_event_id=$1 WHERE id=$2",[event.data.id,rem.id]);res.json({ok:true,eventId:event.data.id,htmlLink:event.data.htmlLink});
}));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.use((err,req,res,next)=>{
 console.error(err.stack||err);
 if(err instanceof z.ZodError)return res.status(400).json({error:"Please check the entered details",details:err.issues.map(i=>({field:i.path.join("."),message:i.message}))});
 const status=err.status|| (err.code==="23505"?409:500);
 res.status(status).json({error:status>=500?"The server could not complete that request. Check server logs and configuration.":err.message});
});
schemaReady=initDb().catch(e=>{console.error("Database initialization failed:",e.message);throw e;});
app.listen(PORT,"0.0.0.0",()=>console.log(`MUNAISZN Business Manager listening on ${PORT}`));
