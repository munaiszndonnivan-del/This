# MUNAISZN Business Manager — Full SaaS Project

A multi-tenant Node.js + PostgreSQL SaaS foundation with a mobile-first dashboard and server-backed business operations. This package includes source code, database schema, deployment configuration, and a real Daraja STK Push request/callback flow. It is not a live payment account or an already-deployed hosted service.

## Included

- Business registration, password login, JWT sessions, hashed passwords, tenant-scoped queries.
- Dashboard, Sales/POS, orders/receipts, products/services, inventory movements, customers, suppliers, expenses, invoices, reports, reminders, M-Pesa hub, subscriptions, team/roles, audit logs, platform admin.
- PostgreSQL persistence, database constraints, stock row locks and no-negative-stock checks in POS and inventory adjustments.
- Daraja STK Push with OAuth token request, phone validation, Paybill/Till transaction type configuration, public callback endpoint, callback idempotency guard, receipt capture, transaction status.
- Google OAuth consent flow and Calendar event creation for reminders when Google Cloud credentials are configured.
- Dockerfile and Render blueprint.
- KES and Africa/Nairobi defaults. Plan prices Free / Pro KSh 499 / Business KSh 999.

## Important: what is and is not turnkey

This is the complete source project to deploy; the app cannot become a public SaaS until a hosting provider, PostgreSQL database, domain/URL and secret environment variables are configured. No assistant can provision Safaricom production access or create credentials for you.

**Live M-Pesa cannot work with sandbox shortcode `174379`.** Safaricom must approve/enable your production Lipa na M-PESA product and provide the production shortcode, consumer key/secret and passkey. Until then set `MPESA_ENV=sandbox`. A successful STK request means Safaricom accepted the prompt request; only a successful callback marks the transaction paid. The callback endpoint is `/api/mpesa/callback`, and must be reachable publicly over HTTPS.

## Deployment outline

1. Create a managed PostgreSQL database with your host (Render, Railway, or another Node/Docker host).
2. Deploy this repository/project using its Dockerfile.
3. Set every required variable from `.env.example` in the host dashboard. Use a long random `JWT_SECRET`; never commit secrets.
4. Set `APP_URL`, `CORS_ORIGIN`, and `MPESA_CALLBACK_URL=https://YOUR_DOMAIN/api/mpesa/callback`.
5. Start in sandbox and test with Safaricom's sandbox app and approved test numbers. Do not treat sandbox funds as real money.
6. When Safaricom grants production access, replace the Daraja credentials, passkey, shortcode and transaction type together, then set `MPESA_ENV=live`. Do not just flip the environment variable while retaining sandbox credentials.
7. For Google Calendar, create OAuth credentials in Google Cloud Console, add the exact redirect URL `https://YOUR_DOMAIN/api/google/callback`, enable Google Calendar API, and set the client ID/secret/redirect URI.
8. Configure `PLATFORM_ADMIN_EMAIL` to the platform operator's account email. Register that account, then use the admin section to review tenants.

## Required environment variables

- `DATABASE_URL`: PostgreSQL connection URL.
- `JWT_SECRET`: 32+ random characters.
- `APP_URL`, `CORS_ORIGIN`, `PLATFORM_ADMIN_EMAIL`.
- Daraja: `MPESA_ENV`, `MPESA_CONSUMER_KEY`, `MPESA_CONSUMER_SECRET`, `MPESA_SHORTCODE`, `MPESA_PASSKEY`, `MPESA_CALLBACK_URL`, `MPESA_TRANSACTION_TYPE`.
- Google is optional until enabled: `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI`.

`DATABASE_SSL=true` is the production default for hosted PostgreSQL. Set `DATABASE_SSL=false` only for a local database that does not support TLS.

## Security and operational notes

- Keep `.env` private. Do not paste secrets into chat, GitHub or browser settings.
- Use a managed database with backups and TLS. Rotate secrets if exposed.
- Callback endpoints must be public HTTPS. Safaricom's callback is not authenticated by this app with a cryptographic signature, so production operators should add network/provider verification and reconciliation against the Daraja query API before relying on payments for high-value fulfillment.
- This project has no card processing or email delivery provider configured. Invoice records and print-to-PDF receipts are available; automatic email delivery requires a mail provider.
- Subscription reference submission is recorded for manual verification; it deliberately does not auto-activate a plan based on an unverified user-entered reference. Automatic platform subscription activation would require a separate verified platform payment integration.
- Plans are defined in the subscription endpoint. Server-side plan entitlement limits and billing automation should be completed before selling paid access at scale; this starter currently provides plan display/history and admin status management.
- Google Calendar OAuth requires credentials and user consent. Google Sign-In as an alternative login provider is not implemented; account login is email/password. Calendar connection is implemented separately.
- Apply backups, monitoring, error alerting, privacy policy, terms of service, data retention controls, and independent security review before commercial production.

## Main routes

- `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`
- `GET /api/dashboard`
- CRUD: `/api/products`, `/api/customers`, `/api/suppliers`, `/api/expenses`, `/api/invoices`, `/api/reminders`
- `POST /api/sales`, `GET /api/sales`, `GET /api/sales/:id`
- `POST /api/stock/adjust`, `GET /api/stock/ledger`
- `POST /api/mpesa/stkpush`, `POST /api/mpesa/callback`, `GET /api/mpesa/transactions`
- `GET /api/reports/summary`, `GET /api/audit`, `/api/team`
- `/api/subscriptions/*`, `/api/admin/*`
- `/api/google/auth`, `/api/google/callback`, `POST /api/reminders/:id/calendar`

## Default business roles

- Owner: full workspace control.
- Manager: day-to-day operations, product and inventory management.
- Cashier: sales workflow.
- Accountant: expense/report/audit workflows.

## Local development

Requires Node.js 20+ and PostgreSQL. This backend is intended to run on a compatible Node host, not inside Pydroid's Python terminal.

```bash
cp .env.example .env
# Edit .env with a PostgreSQL URL and JWT_SECRET
npm install
npm start
```

The schema is applied automatically at startup. Visit `http://localhost:3000`.
